package com.example.hi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
